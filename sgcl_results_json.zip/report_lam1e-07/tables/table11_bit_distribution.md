**Table 11. Sensitivity of CER and RIF to the bit-position distribution (ResNet-18, CIFAR-10, λ = 10^-7).**

| Bit-position distribution (sign / exponent / mantissa) | Baseline CER (%) | Unified CER (%) | RIF |
|---|---|---|---|
| Uniform (1/32, 8/32, 23/32) | 1.95 | 0.21 | 9.21× |
| Exponent-weighted (0.05 / 0.60 / 0.35) | 5.13 | 0.06 | 84.99× |
| Mantissa-weighted (0.05 / 0.10 / 0.85) | 0.79 | 0.02 | 46.68× |
