**Table 5. Variance (of per-seed accuracy, fraction²) and standard deviation of accuracy, catastrophic trials and CER suppression by fault-aware training on CIFAR-10.**

| Model | Acc. variance, fraction² (baseline) | Acc. variance, fraction² (FAT) | Variance reduction (%) | Std reduction (%) | Acc. SD pp (baseline) | Acc. SD pp (FAT) | Trials with acc < 50 % (baseline / FAT) | SD pp excl. those trials (baseline / FAT) | CER baseline (%) | CER FAT (%) | CER suppression (%) | Training overhead (%) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| EfficientNet-B0 | 4.94e-04 | 3.55e-04 | 28.1 | 15.2 | 2.22 | 1.88 | 1 / 1 | 0.083 / 0.131 | 0.15 | 0.15 | 1.7 | +160 |
| ResNet-18 | 1.47e-02 | 1.37e-02 | 7.1 | 3.6 | 12.14 | 11.69 | 12 / 13 | 0.070 / 0.132 | 1.95 | 2.07 | -6.1 | +135 |
