**Table 7. Ablation of the proposed framework with paired statistical tests (ResNet-18, CIFAR-10, λ = 10^-7).**

| Configuration | CER (%) | Absolute CER reduction (pp) | z-score | p (Bonferroni, m = 4) | 95 % CI (pp) | RIF |
|---|---|---|---|---|---|---|
| Baseline | 1.95 | – | – | – | – | 1.00× |
| Architecture-only | 0.07 | 1.89 | 3.48 | 0.002 | [0.83, 2.95] | 30.05× |
| Training-only | 2.07 | -0.12 | -0.76 | 1.000 | [-0.43, 0.19] | 0.94× |
| Optimization-only | 1.04 | 0.92 | 1.94 | 0.209 | [-0.01, 1.84] | 1.89× |
| Unified framework | 0.21 | 1.74 | 3.29 | 0.004 | [0.70, 2.78] | 9.21× |
