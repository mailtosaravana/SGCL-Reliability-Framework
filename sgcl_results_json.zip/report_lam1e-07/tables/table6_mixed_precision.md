**Table 6. Mixed-precision allocation policies (ResNet-18, CIFAR-10, λ = 10^-7).**

| ID | Precision policy | CER (%) | ΔCER vs baseline (rel. %) | Latency change (%) | Memory change (%) | Energy change (%) |
|---|---|---|---|---|---|---|
| Baseline | Uniform FP32 (reference) | 1.95 | 0.0 | 0.0 | 0.0 | 0.0 |
| MP-1 | uniform FP16 | 1.33 | -32.1 | -50.0 | -50.0 | -40.0 |
| MP-2 | uniform FP8 | 1.49 | -23.8 | -70.0 | -75.0 | -60.0 |
| MP-3 | FP32 critical + FP16 others | 1.38 | -29.3 | -24.2 | -47.0 | -19.3 |
| MP-4 | FP16 critical + FP8 others | 1.10 | -43.6 | -59.7 | -73.5 | -49.7 |
| MP-5 | FP32 stem+head + FP8 others | 1.38 | -29.1 | -69.8 | -75.0 | -59.8 |
