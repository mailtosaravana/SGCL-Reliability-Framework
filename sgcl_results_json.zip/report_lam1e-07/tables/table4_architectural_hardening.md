**Table 4. RIF and inference overhead of architectural hardening (CIFAR-10, λ = 10^-7).**

| Model | Baseline CER (%) | Hardened CER (%) | RIF | Inference overhead (%) |
|---|---|---|---|---|
| ResNet-18 | 1.95 | 0.07 | 30.05× | +51.7 |
