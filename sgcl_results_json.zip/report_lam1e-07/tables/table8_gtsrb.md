**Table 8. Application-level functional-failure rates on GTSRB (ResNet-18, λ = 10^-7).**

| Configuration | λ | Decision rate | CER (%) | Failures / hour | Fault-induced misclassifications per 10⁹ decisions | Reduction factor (RIF) | Paired test vs baseline |
|---|---|---|---|---|---|---|---|
| Baseline | 10^-7 | 10 Hz | 2.47 | 889.8 | 2.47e+07 | 1.000× | – |
| Architecture-only | 10^-7 | 10 Hz | 0.26 | 94.6 | 2.63e+06 | 9.410× | z = 3.70, adj. p = 8.6×10^-4 |
| Training-only | 10^-7 | 10 Hz | 2.57 | 924.4 | 2.57e+07 | 0.963× | z = -3.71, adj. p = 8.3×10^-4 |
| Optimization-only | 10^-7 | 10 Hz | 1.40 | 503.6 | 1.40e+07 | 1.767× | z = 2.00, adj. p = 0.180 |
| Unified framework | 10^-7 | 10 Hz | 0.18 | 63.8 | 1.77e+06 | 13.953× | z = 3.63, adj. p = 0.001 |
