**Table 10. Matched comparison with re-implemented methods (ResNet-18, CIFAR-10, λ = 10^-7).**

| Method | Layer of the reliability stack | Clean accuracy (%) | CER at λ = 10^-7 (%) | RIF | Inference-cost change (%) | ΔCER vs unified (pp) [95 % CI] | z / adjusted p |
|---|---|---|---|---|---|---|---|
| Baseline (unprotected) | – | 91.38 | 1.95 | 1.00× | +0.0 | 1.74 [0.70, 2.78] | 3.29 / 0.004 |
| Range restriction [34] | Architecture | 91.34 | 0.02 | 119.09× | +1.1 | -0.20 [-0.45, 0.06] | -1.51 / 0.524 |
| FAT-RABBIT [35] | Training | 76.09 | 2.05 | 0.95× | +0.0 | 1.83 [0.96, 2.70] | 4.13 / 1.4×10^-4 |
| RAP [40] | Optimization (pruning) | 91.21 | 1.18 | 1.66× | -44.9 | 0.97 [0.17, 1.77] | 2.37 / 0.071 |
| RL bit protection [36] | Bit-level protection | 91.38 | 1.94 | 1.01× | +2.6 | 1.73 [0.69, 2.77] | 3.27 / 0.004 |
| Proposed unified framework | Cross-layer | 84.52 | 0.21 | 9.21× | -29.6 | – | – |
